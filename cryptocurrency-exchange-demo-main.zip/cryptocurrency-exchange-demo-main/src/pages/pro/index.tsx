
import 'bootstrap/dist/css/bootstrap.min.css';


export default function Pro(){



    return(
        <div className="text-center text-9xl m-auto" style={{marginTop:"300px"}}>
            <h1>Coming Sooon....</h1>
        </div>
    )



}